from distutils.core import setup

setup(
    name='CcxMLOGE',
    version='0.0.0',
    packages=['ccxMLogE'],
    url='2017-11-28',
    license='ccx',
    author='liyingkun',
    author_email='liyingkun@ccx.cn',
    description='机器学习平台一期--万象智慧--MLogE',
    data_files=[('', ['setup.py'])]
)
